# Ada–Workspace OS Implementation Log
Date: 18 October 2026 — Australia/Brisbane
Status: Initial implementation; acceptance testing INCOMPLETE.
Original integration specification remains DRAFT — NOT ADOPTED.

## Decisions and scope
The user selected a new saved global specialist named Liam.
Role: query Ada, report sourced evidence and limitations, and separate interpretation from evidence.
This work implements the initial single-specialist connection.
No swarm configuration, delegation, PRF-specific role or automatic archival write-back was added.
Liam is not technically exclusive: legacy all-grant runs can access evidence.query.

## Saved specialist
Path: ~/.claude/agents/liam.md
Mode: safe
Capability: evidence
Home surface: knowledge
Safe mode and persona instructions do not enforce read-only access across all agent tools.
A saved persona does not establish continuous operation or persistent conversational memory.

## Recovery snapshot
~/Desktop/ruflo-test/ada/workspace-integration-backup-20261018-120131/
Contains originals of capabilityCatalog.ts, grants.ts, actionBridge.ts and liam.md,
plus a manifest recording source paths, Git revision and working-tree status.

## Implementation
Modified in ~/Desktop/Workspace-OS/:
- src/main/agent/capabilityCatalog.ts: registered evidence and command guidance.
- src/main/agent/grants.ts: mapped evidence to the evidence. prefix.
- src/main/agent/actionBridge.ts: routed evidence.query after authorization checks;
  added an evidence-specific matching-open-workspace check.

Created:
- src/main/agent/evidenceAction.ts
- src/main/agent/evidencePermissions.test.ts
- src/main/agent/evidenceAction.test.ts
- ~/Desktop/ruflo-test/ada/ada_workspace_adapter_v01.py

Updated ~/.claude/agents/liam.md with capability and bridge instructions.
Existing Ada service, retrieval code, checker, contracts and checkpoints were not
edited by the implementation commands. No archival write-back was implemented.

## Interface and initial limits
Action: evidence.query
Input: object containing only a nonempty question string.
Question limit: 4000 UTF-8 bytes.
Python adapter request limit: 8192 bytes.
Process output limit: 256 KiB; timeout: 10 seconds; termination signal: SIGKILL.
Fixed Python interpreter:
 /Library/Frameworks/Python.framework/Versions/3.14/bin/python3
Fixed adapter location: ~/Desktop/ruflo-test/ada/ada_workspace_adapter_v01.py
Invocation uses -B -E -s, stdin JSON and no shell.
Adapter calls ada_evidence_service_v03.research(question).
Response preserves schema ada.evidence_response.v0.1, null answer,
UNRESOLVED semantic support and RETRIEVAL_ONLY status.
VERIFIED_MATCH establishes excerpt matching, not truth or governance adoption.

## Verification observed
1. Direct Python adapter query returned parseable evidence JSON with five
   source entries reporting VERIFIED_MATCH and source paths/line ranges.
2. TypeScript compiler availability confirmed: version 5.9.3.
3. Dependency-backed typecheck reported no regressions:
   70 known errors against baseline 75. The project is not type-error-free.
4. git diff --check reported no issues at the recorded check.
5. Macro validation passed.
6. Four targeted test files passed: 42 tests total.
   - Existing grants: 3.
   - Existing bridge: 12.
   - Evidence permissions: 9.
   - Evidence action handler: 18.
7. Permission tests covered authorized routing, missing token, missing grant,
   revoked token, wrong workspace, no open workspace, missing authorization
   dependency, narrow evidence prefixes and legacy all-grant access.
8. Handler tests covered input rejection, fixed invocation/limits, malformed
   responses, retrieval-contract checks and simulated process failures.
   Simulations do not demonstrate actual timeout or output-limit enforcement.
9. App build completed.
10. Electron preview launched after runtime installation and native rebuild.
11. Liam appeared in the specialist roster.
12. Live UI showed wos-action run evidence.query for the governance question.
    Liam reported five VERIFIED_MATCH sources and preserved retrieval-only
    limitations while separating interpretation.
    Raw live tool-response JSON was not independently inspected.
    The visible workspace indicator remained WARRIGAL RESEARCH SUITE;
    a switch to ruflo-test was requested but not confirmed.

## Environment issues and corrections
Initial typecheck success was unreliable while node_modules was absent.
The wrapper can mistake compiler failures without error TS lines for success.
The baseline was not intentionally accepted or changed.
npm ci initially failed on the React-plugin/Vite peer conflict.
npm ci --include=dev --legacy-peer-deps installed 982 packages.
Peer compatibility remains a maintenance issue.
npm reported 44 vulnerabilities: 14 moderate, 29 high, 1 critical.
Install-script warnings were reported; approvals were not comprehensively reviewed.
Electron runtime was missing and installed using its packaged install.js.
Preview then encountered a better-sqlite3 ABI mismatch (147 versus required 146).
npm run rebuild:electron completed; two native addons were signed and verified.
Subsequent startup log did not show that mismatch.
Node-based native tests may require rebuilding back for Node.
The modified preview build has not replaced the installed application.

## Reporting issue
Liam formatted some paraphrases as blockquotes.
Pending instruction refinement: reserve quotations/blockquotes for exact text;
label summaries as paraphrases and retain the original source references.

## Remaining acceptance work
- Inspect and retain raw live bridge response and run/provider details.
- Confirm actual specialist grant issuance and workspace binding in the launcher.
- Test real timeout, output overflow, missing backend and invalid adapter requests.
- Verify no unintended adapter writes; -B alone is not a filesystem sandbox.
- Run broader relevant regression tests and document results.
- Demonstrate rollback in an isolated copy.
- Review source boundary weaknesses, including parent symlinks and filesystem races.
- Verify Codex provider support; do not infer it from the observed Claude run.
- Review dependency vulnerabilities, peer conflict and install-script state.
- Fix the typecheck wrapper's handling of compiler execution failures.
- Review full diff, preserve a local Git checkpoint and reconcile specification status.
- No full acceptance, production-readiness or broader deployment claim is made.

## Rollback plan — not demonstrated
Stop preview. Restore the three modified Workspace OS files and Liam profile
from the recorded snapshot. Remove only the newly added integration and test
files listed above after reviewing intervening changes. Rebuild and rerun checks.
Preserve Ada prototypes/checkpoints, original contracts and the canonical archive.
Dependency installation and runtime/native rebuilds are separate environment changes.
