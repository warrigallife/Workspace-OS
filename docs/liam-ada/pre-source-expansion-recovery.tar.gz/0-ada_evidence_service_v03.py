"""Ada evidence service v0.3: approved-source retrieval prototype."""
from pathlib import Path
import ada_v04 as ada
import ada_evidence_checker_v02 as checker

SCHEMA = "ada.evidence_response.v0.1"

APPROVED_SOURCES = (
    "governance/GOVERNANCE_CONSTITUTION_v0.1_DRAFT.md",
    "governance/AGENT_CONTRACT_v0.1_DRAFT.md",
    "governance/OPERATIONAL_HANDOVER_PROTOCOL_v0.1_DRAFT.md",
    "WORKFORCE_FINDINGS.md",
    "dev-team/STATUS.md",
)

APPROVED_REPORT = (
    Path.home() / "Desktop/WARRIGAL RESEARCH SUITE/docs/reports/"
    "WARRIGAL_REPOSITORY_RECONCILIATION_2026-10-18.md"
)

def approved_paths():
    return tuple(ada.ROOT / name for name in APPROVED_SOURCES) + (
        APPROVED_REPORT,
    )

def load_approved_sections():
    sections = []
    for path in approved_paths():
        if path.is_symlink() or not path.is_file():
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeError):
            continue
        for offset in range(0, len(lines), 12):
            start = offset + 1
            end = min(offset + 18, len(lines))
            excerpt = "\n".join(
                f"{i}: {lines[i-1]}" for i in range(start, end + 1)
            )
            terms = ada.tokens(excerpt)
            sections.append((path, start, end, excerpt, terms))
    return sections

def research(question):
    approved = approved_paths()
    evidence = ada.retrieve(question, load_approved_sections())
    sources = []
    for number, record in enumerate(evidence, 1):
        integrity = checker.verify_excerpt(record, approved)
        sources.append({
            "id": number,
            "path": str(record[0]),
            "lines": [record[1], record[2]],
            "excerpt": record[3],
            "integrity": integrity,
        })
    return {
        "schema": SCHEMA,
        "question": question,
        "sources": sources,
        "answer": None,
        "semantic_support": "UNRESOLVED",
        "status": "RETRIEVAL_ONLY",
    }
