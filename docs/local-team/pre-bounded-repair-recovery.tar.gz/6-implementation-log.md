# Local Python-function pilot implementation record — 2026-10-19

Continued the existing Workspace OS/Ruflo/Ollama inspection and Liam–Ada checkpoint `a4a1bce`. No discovery restart, reinstall, swarm activation or profile expansion. Scope was narrowed explicitly to a standalone Python function artifact workflow with independent user-supplied checks. This is not a general-purpose agent team.

Before editing, saved 15 selected source/profile originals in `pre-team-recovery.tar.gz` with a path/SHA256 manifest. Existing prototypes, archives and prior Git checkpoints were preserved. Added a local-only launcher branch, sequential persistent queue, restricted Python worker, direct installed Ruflo task-handler adapter, reviewer gate, handover evidence, restart/retry UI and named Desktop launcher. No source allowlist or Liam–Ada runtime change was required.

Reconciled the saved acceptance artifacts instead of rerunning successful work:

| Evidence directory | Observed result |
| --- | --- |
| `acceptance/initial-model-failure` | Candidate called `isdigit` on integers; real execution failed. No completion. |
| `acceptance/initial-format-failure` | Local response hit its token limit/malformed JSON. No execution/completion claim. |
| `acceptance/initial-intentional-contract-failure` | Model returned `print(1)` instead of the required function; rejected by executable contract. |
| `acceptance/review-drill-contract-failure` | First review drill also failed before review; not counted as a reviewer-rejection test. |
| `acceptance/success` | Actual Agents UI submission; sandbox produced 6, 0 and 3 for supplied inputs; Nora approved; Marguerite note and trusted handover saved. Final checkpoint `aa11268b7fe59b28fab138c5a1cd1988d2d54491`. |
| `acceptance/intentional-failure` | Valid function actually returned 6 with exit 0; independent expected value was deliberately 7. Execution gate blocked review/completion. |
| `acceptance/review-rejection` | All three execution checks passed; actual local Nora reply was `reject`; completion blocked. |
| `acceptance/cancelled` | User-facing Cancel ended the attempt; queue and saved state say cancelled. |
| `acceptance/interrupted` | Orderly app close/relaunch produced interrupted queue status. Last stage snapshot remained running; explicitly not considered live/completed. |
| `acceptance/recovered` | UI Retry made a new attempt linked to the interrupted ID; actual output 5 matched expected 5, Nora approved and handover/checkpoint saved. |

`acceptance/summary.json` records the remaining-check run and its exact queue/checkpoint IDs. Every saved evidence hash was compared with its retained artifact and matched. No prior failure was relabeled as success. Typed input examples and bounded structured-output schemas fixed prompting/formatting defects for this pilot, without changing its expected values or relaxing execution/review gates.

Security and regression checks: eight Python tests passed using real sandbox/installed-ledger operations and deterministic model fixtures. These include successful execution, mismatched expected result, AST denials, direct OS denials for private reads/writes/network/fork, persistent task IDs/status, reviewer rejection, missing model with no fallback and evidence hashes. The broader Electron suite passed 274 tests across 27 files before the final persistence refinement. The final focused queue/local-boundary suite passed 12 tests across two files, including strict corrupt-queue refusal and late completion after shutdown. No new native ABI rebuild or dependency change was made.

The sandbox startup defect was traced to required root-directory metadata and Python's wrapper → actual interpreter executable. Both runtime paths are allowed explicitly; user file contents, writes, network and forks remain denied. An attempted hard data-memory limit was rejected by macOS and removed; no hard RSS cap is claimed. CPU/wall/output limits remain. Real local inference and cloud credential absence are recorded in the saved model/state evidence; all successful attempts used installed Llama 3.2, with no cloud fallback.

Desktop launcher `~/Desktop/Workspace OS — Local Python Pilot.command` has mode 0755 and delegates to this checkout's established local app-data route. The old local instance had no active background jobs; it was closed gracefully, existing app data was copied to the ignored private recovery folder, and `desktop-check.mjs` verified the actual Desktop executable opened this checkout, the established `.workspace-os/liam-app-data`, the pilot panel and the existing Liam profile. It made zero model calls. See `desktop-launch.json`.

Remaining limitations: arbitrary Python tasks are unreliable with this small model; execution accepts only the documented syntax/builtin subset; tests cover supplied examples, not all semantics; the reviewer is a separate invocation of the same model; cancellation cannot guarantee immediate cessation inside the Ollama daemon; interrupted stage snapshots can remain stale; hard-crash recovery was not live-tested; no hard memory cap. No autonomous project writes or broader specialist coordination is implemented. Recovery instructions and private backup locations are in README.

Final reconciliation: the Desktop route rebuilt successfully, with the existing Vite/plugin warnings. The final built Liam–Ada `lookup-bridge.mjs` check passed without a model call: implementation-log lines 145–160 including line 152 matched disk, and all six negative checks rejected as expected. Saved profile files and Ada source allowlist were unchanged.

Final type-check limitation: `npm run typecheck` rejected the node-project compiler's exit status **1** because its wrapper accepts diagnostic exit status 2 only. Direct compiler checks completed: node project produced the same 70 known diagnostics; renderer exited 0 with none. Comparing every `(file, diagnostic-code)` count to the unchanged baseline of 75 found **zero regressions**. The wrapper was not changed or represented as passing. `git diff --check` passed. Acceptance text artifacts were scanned for common credential/private-key patterns with no matches; no runtime token or credential was included. Existing app-data backup remains private and Git-ignored.
